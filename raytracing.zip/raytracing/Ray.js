class Ray{
    constructor(r, refraction, old_refraction){
        this.r = r;
        this.refraction = refraction;
        this.old_refraction = old_refraction;
    }
}